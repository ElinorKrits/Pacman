# make this the lowest priority (will be overridden by commands)
PATH="$PATH:$FORNIX_FOLDER/settings/.cache/path_injection"