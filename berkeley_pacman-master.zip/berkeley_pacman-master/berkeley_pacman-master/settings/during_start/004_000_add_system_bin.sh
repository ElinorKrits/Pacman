# make this the lowest priority (will be overridden by commands)
PATH="$PATH:/usr/bin"
export PATH="$PATH/$HOME/.local/bin"