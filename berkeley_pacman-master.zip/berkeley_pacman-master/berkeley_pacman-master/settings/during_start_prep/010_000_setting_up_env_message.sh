# if no arguments (just starting up the shell)
if [ -z "$FORNIX_ARGS" ]
then
    echo "=============================="
    echo " Setting up your Environment!"
    echo "=============================="
fi