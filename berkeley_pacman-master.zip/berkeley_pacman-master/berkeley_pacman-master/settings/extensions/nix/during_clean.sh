
# detach the system link (behaves like unlink)
"$FORNIX_FOLDER/settings/extensions/#standard/commands/tools/file_system/remove" "$FORNIX_FOLDER/home/.cache/nix"