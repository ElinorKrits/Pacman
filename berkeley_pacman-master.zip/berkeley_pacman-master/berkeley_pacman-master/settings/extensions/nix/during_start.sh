# fix_ssl
. "$FORNIX_FOLDER/settings/extensions/nix/commands/fix_ssl"