# the mac library cache
if [ -d "$FORNIX_FOLDER" ]
then
    "$FORNIX_FOLDER/settings/extensions/#standard/commands/tools/file_system/remove" "$FORNIX_HOME/Library/Caches"
fi